class Item
  attr_accessor :name
end

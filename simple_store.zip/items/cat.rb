class Cat < Item
end
